import { useMovies } from '../context/MoviesContext.js';
import WatchedMovie from './WatchedMovie.jsx';

export default function WatchMovieList() {
  const { watched } = useMovies();
  return (
    <ul className="list">
      {watched.map((movie) => (
        <WatchedMovie key={movie.imdbID} movie={movie} />
      ))}
    </ul>
  );
}
