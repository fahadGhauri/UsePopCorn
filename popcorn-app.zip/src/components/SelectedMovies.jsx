import { useEffect, useRef, useState } from 'react';
import { useMovies } from '../context/MoviesContext.js';
import StarRating from './StarRating.jsx';
import { useKey } from '../hooks/useKey.js';

const KEY = 'ba1fb5c0';

export default function SelectedMovies() {
  const { selectedID, handleClose, onAddWatched, watched, handleAddWatched } = useMovies();
  const [movie, setMovie] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [userRating, setUserRating] = useState(0);
  const countRef = useRef(0);

  useEffect(() => { if (userRating) countRef.current++; }, [userRating]);

  const isWatched = watched.map((m) => m.imdbID).includes(selectedID);
  const watchedUserRating = watched.find((m) => m.imdbID === selectedID)?.userRating;

  const { Title: title, Year: year, Poster: poster, Runtime: runtime, imdbRating, Plot: plot, Released: released, Actors: actors, Director: director, Genre: genre } = movie;

  function handleAdd() {
    const newMovie = {
      imdbID: selectedID,
      title,
      year,
      poster,
      imdbRating: Number(imdbRating),
      runtime: Number(runtime?.split(' ').at(0)) || 0,
      userRating,
      countRatingDecision: countRef.current,
    };
    handleAddWatched(newMovie);
    handleClose();
  }

  useEffect(() => {
    async function getMovie() {
      setIsLoading(true);
      const res = await fetch(`http://www.omdbapi.com/?apikey=${KEY}&i=${selectedID}`);
      const data = await res.json();
      setMovie(data);
      setIsLoading(false);
    }
    getMovie();
  }, [selectedID]);

  useEffect(() => {
    if (!title) return;
    document.title = `Movie | ${title}`;
    return () => { document.title = 'usePopcorn'; };
  }, [title]);

  useKey('Escape', handleClose);

  return (
    <div className="details">
      {isLoading ? (
        <p className="loader">Loading...</p>
      ) : (
        <>
          <header>
            <button className="btn-back" onClick={handleClose}>&larr;</button>
            <img src={poster} alt={`Poster of ${title} movie`} className="movie-poster" />
            <div className="details-overview">
              <h2>{title}</h2>
              <p>{released} &bull; {runtime}</p>
              <p>{genre}</p>
              <p><span>⭐️</span> {imdbRating} IMDb rating</p>
            </div>
          </header>

          <section>
            <div className="rating">
              {!isWatched ? (
                <>
                  <StarRating maxRating={10} size={24} onSetRating={setUserRating} />
                  {userRating > 0 && (
                    <button className="btn btn-primary" onClick={handleAdd}>+ Add to list</button>
                  )}
                </>
              ) : (
                <p>You rated this movie <span>⭐️</span> {watchedUserRating}</p>
              )}
            </div>
            <p><em>{plot}</em></p>
            <p>Starring {actors}</p>
            <p>Directed by {director}</p>
          </section>
        </>
      )}
    </div>
  );
}
