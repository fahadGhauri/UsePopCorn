import { useMovies } from '../context/MoviesContext.js';

const average = (arr) => arr.reduce((acc, cur) => acc + cur / arr.length, 0);

export default function WatchSummary() {
  const { watched } = useMovies();
  const avgImdb = watched.length ? average(watched.map(m => m.imdbRating)).toFixed(2) : 0;
  const avgUser = watched.length ? average(watched.map(m => m.userRating)).toFixed(2) : 0;
  const avgRuntime = watched.length ? Math.round(average(watched.map(m => m.runtime))) : 0;

  return (
    <div className="summary">
      <h2>Movies you watched</h2>
      <div>
        <p><span>#️⃣</span> {watched.length} movies</p>
        <p><span>⭐️</span> {avgImdb}</p>
        <p><span>🌟</span> {avgUser}</p>
        <p><span>⏳</span> {avgRuntime} min</p>
      </div>
    </div>
  );
}
