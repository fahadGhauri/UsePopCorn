import { useRef } from 'react';
import { useMovies } from '../context/MoviesContext.js';
import { useKey } from '../hooks/useKey.js';

export default function SearchBar() {
  const { query, setQuery } = useMovies();
  const inputEL = useRef(null);

  useKey('Enter', function () {
    if (document.activeElement === inputEL.current) return;
    inputEL.current?.focus();
    setQuery('');
  });

  return (
    <input
      ref={inputEL}
      className="search"
      type="text"
      placeholder="Search movies..."
      value={query}
      onChange={(e) => setQuery(e.target.value)}
    />
  );
}
