import { useMovies } from '../context/MoviesContext.js';

export default function WatchedMovie({ movie }) {
  const { handleDelet } = useMovies();

  return (
    <li>
      <img className="movie-poster" src={movie.poster} alt={`${movie.title} poster`} />
      <div style={{display:'grid', gap:6}}>
        <h3 style={{margin:0}}>{movie.title}</h3>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <p><span>⭐️</span> {movie.imdbRating}</p>
          <p><span>🌟</span> {movie.userRating}</p>
          <p><span>⏳</span> {movie.runtime} min</p>
          <button className="btn btn-ghost btn-delete" onClick={() => handleDelet(movie.imdbID)}>Delete</button>
        </div>
      </div>
    </li>
  );
}
