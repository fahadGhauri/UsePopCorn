import { useState } from 'react';
export default function Box({ children }) {
  const [isOpen, setIsOpen] = useState(true);
  return (
    <div className="box">
      <button className="btn btn-ghost" onClick={() => setIsOpen(o => !o)}>{isOpen ? '–' : '+'}</button>
      {isOpen && children}
    </div>
  );
}
