import Movie from './Movie.jsx';

export default function MovieList({ movies }) {
  return (
    <ul className="list list-movies">
      {movies?.map((m) => (
        <Movie key={m.imdbID} movie={m} />
      ))}
    </ul>
  );
}
