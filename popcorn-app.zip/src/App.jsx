import { useState } from 'react';
import Navbar from './components/Navbar.jsx';
import SearchBar from './components/SearchBar.jsx';
import NumResults from './components/NumResults.jsx';
import Main from './components/Main.jsx';
import Box from './components/Box.jsx';
import MovieList from './components/MovieList.jsx';
import WatchSummary from './components/WatchSummary.jsx';
import WatchMovieList from './components/WatchMovieList.jsx';
import SelectedMovies from './components/SelectedMovies.jsx';
import { useMovie } from './hooks/useMovie.js';
import { useMovies } from './context/MoviesContext.js';
import { useLocalStorageState } from './hooks/useLocalStorageState.js';

export default function App() {
  const { query, selectedID } = useMovies();
  const { movies, isLoading, error } = useMovie(query);
  // Keep watched in localStorage but also expose via context (optional enhancement)
  // We will hydrate context modifications via SelectedMovies etc. so no change here.

  function ErrorMessage({ message }) {
    return <p className="error"><span>🚫</span> {message}</p>;
  }

  return (
    <>
      <Navbar>
        <div className="logo"><span role="img">🍿</span><h1>usePopcorn</h1></div>
        <SearchBar />
        <NumResults movies={movies} />
      </Navbar>

      <Main>
        <Box>
          {isLoading && <p className="loader">Loading...</p>}
          {!isLoading && !error && <MovieList movies={movies} />}
          {error && <ErrorMessage message={error} />}
        </Box>

        <Box>
          {selectedID ? (
            <SelectedMovies />
          ) : (
            <>
              <WatchSummary />
              <WatchMovieList />
            </>
          )}
        </Box>
      </Main>
    </>
  );
}
