import { createContext, useContext, useState } from 'react';

const MoviesContext = createContext();

export function MoviesProvider({ children }) {
  const [query, setQuery] = useState('');
  const [selectedID, setSelectedID] = useState(null);
  const [watched, setWatched] = useState([]);

  function handleSeled(id) {
    setSelectedID(prev => (prev === id ? null : id));
  }
  function handleClose() { setSelectedID(null); }
  function handleAddWatched(movie) { setWatched(prev => [...prev, movie]); }
  function handleDelet(id) { setWatched(prev => prev.filter(m => m.imdbID !== id)); }

  return (
    <MoviesContext.Provider value={{ query, setQuery, selectedID, handleSeled, handleClose, watched, handleAddWatched, handleDelet }}>
      {children}
    </MoviesContext.Provider>
  );
}

export function useMovies() {
  const ctx = useContext(MoviesContext);
  if (!ctx) throw new Error('useMovies must be used within MoviesProvider');
  return ctx;
}
