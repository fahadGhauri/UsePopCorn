import { useState, useEffect } from 'react';

const KEY = 'ba1fb5c0';

export function useMovie(query, callback) {
  const [movies, setMovies] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    callback?.();
    const controller = new AbortController();

    async function fetchMovies() {
      try {
        setIsLoading(true);
        setError('');
        const res = await fetch(`http://www.omdbapi.com/?apikey=${KEY}&s=${encodeURIComponent(query)}`, { signal: controller.signal });
        if (!res.ok) throw new Error('Internet not available');
        const data = await res.json();
        if (data.Response === 'False') throw new Error('Movie not found');
        setMovies(data.Search);
      } catch (err) {
        if (err.name !== 'AbortError') setError(err.message);
      } finally {
        setIsLoading(false);
      }
    }

    if (!query || query.length < 3) { setMovies([]); setError(''); return; }
    fetchMovies();
    return () => controller.abort();
  }, [query, callback]);

  return { movies, isLoading, error };
}
