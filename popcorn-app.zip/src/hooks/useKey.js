import { useEffect } from 'react';

export function useKey(key, action) {
  useEffect(() => {
    function onKey(e) {
      if (e.code.toLowerCase() === key.toLowerCase()) action();
    }
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [key, action]);
}
